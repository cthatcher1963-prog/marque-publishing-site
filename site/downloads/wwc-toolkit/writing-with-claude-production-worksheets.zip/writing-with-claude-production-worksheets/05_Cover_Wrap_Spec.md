# Cover Wrap Spec Sheet — [Title]

**Format:** [ ] Paperback  [ ] Hardcover
**Platform:** [ ] KDP  [ ] IngramSpark  [ ] B&N Press  [ ] Other: _______
**Date built:** [YYYY-MM-DD]

---

## Instructions

One spec sheet per format per platform. The wrap is a three-panel layout: back cover + spine + front cover, printed as a single image. The spine width comes from the frozen page count — do not build the wrap until the count is frozen from Build B.

If the page count changes for any reason, the wrap must be rebuilt.

---

## Dimensions

*Get these from the platform. Every platform differs. Use the platform's own template or calculator, never another platform's numbers.*

| Measurement | Value |
|-------------|-------|
| **Trim size** | _______ × _______ in |
| **Page count (frozen, from Build B PDF)** | _______ pages |
| **Paper stock** | [ ] Cream  [ ] White |
| **Spine width** | _______ in |

### Spine Width Calculation

| Stock | Formula | Result |
|-------|---------|--------|
| Cream (Marque standard) | pages × 0.0025 in | _______ in |
| White | pages × 0.002252 in | _______ in |

**Hardcover spine math differs from paperback.** Confirm per platform against that platform's own current calculator or help table.

---

## Wrap Layout

| Panel | Width | Height | Content |
|-------|-------|--------|---------|
| Back cover | [trim width] | [trim height] | Description, blurbs, barcode, back-cover ISBN |
| Spine | [spine width] | [trim height] | Title, author name, imprint logo |
| Front cover | [trim width] | [trim height] | Your approved front cover |

**Total wrap width:** back + spine + front + bleed on all sides

**Bleed:** _______ in per side *(typically 0.125 in — confirm per platform)*

---

## Checklist

- [ ] Spine width computed from Build B page count (not estimated, not from Build A)
- [ ] Platform template downloaded and dimensions verified
- [ ] Front cover placed at correct resolution (300 DPI minimum for print)
- [ ] Spine text readable at the computed width (if spine is too narrow for text, platform may require blank spine)
- [ ] Back cover includes: description, barcode area, ISBN text
- [ ] Barcode: [ ] Platform supplies its own (KDP) [ ] I supply mine (IngramSpark, Lulu)
- [ ] ⚠ **ISBN on the wrap matches this format's ISBN in the log** — a hardcover wrap carrying the paperback ISBN passes every dimension check but is wrong
- [ ] Bleed extends on all four sides
- [ ] No important text or art in the trim zone
- [ ] Author approved the wrap before upload
- [ ] If platform adds its own barcode, my embedded barcode is removed (double barcodes get covers rejected)

---

## Barcode Notes

| Platform | Barcode handling |
|----------|-----------------|
| KDP | Supplies its own. Leave space but do not embed one. |
| IngramSpark | Prints what you give them. Supply your own. |
| Lulu | Prints what you give them. Supply your own. |
| B&N Press | Check current requirements. |

**Barcode format:** Bookland EAN. Price encoding: use `90000` (no price) unless the price is final and won't change. Barcodes generated from IngramSpark or Lulu must have text outlined — Ghostscript standard-14 fonts in generated barcode PDFs fail preflight for unembedded fonts.

**The printed ISBN text** in a back-cover bullet list is yours on every channel, barcode or not, and is a separate thing to proofread per format.
