# Production Worksheet Templates

Downloadable companion to *Writing with Claude* — Chapters 11 and 12.

These are the worksheets behind the production run. Copy the folder into your book project. Give the files to Claude. Work them in order.

## The Files

| File | What it is | When to use it |
|------|-----------|---------------|
| `00_Production_Run_Sheet.md` | Master checklist with owner column — every task across all three phases, marked Claude or Author | Open this first. It's the run sheet for the whole production. |
| `01_ISBN_Log.csv` | Template for tracking every ISBN your imprint owns | One log, all titles, for life. Start it before your first production run. |
| `01_ISBN_Log_Instructions.md` | How to use the ISBN log | Read once. The rules are simple but the mistakes are irreversible. |
| `02_Interior_Spec_Worksheet.md` | One-page, eight-decision interior spec + geometry checks + trap list | Fill before typesetting. Fiction and nonfiction are different systems. |
| `03_Copyright_Page_Template.md` | Fill-in copyright page with placeholder discipline rules | Build early. Every identifier line the final page will carry must be present now. |
| `04_Metadata_Worksheet.md` | Per-title metadata: description, keywords, categories, pricing | Fill once. Reuse at every platform so the record is consistent. |
| `05_Cover_Wrap_Spec.md` | Cover wrap dimensions, spine math, barcode handling, per-format checklist | One per format per platform. Cannot build until page count is frozen. |
| `06_Platform_Upload_Checklist.md` | Per-platform field-by-field upload guide for KDP, IngramSpark, B&N, D2D | The sitting sheet. Data on the left, platform on the right. |
| `07_Deposit_and_Registration.md` | Copyright registration fields + three-obligation mailing checklist | Phase 3. Know your deadline before you publish. |
| `08_Editorial_Brief_Template.md` | The brief you hand an editor -- or Claude -- before any edit starts: voice, scope, the edit-not-rewrite rule, deliverables | Chapter 10. Write it before you talk to anyone. |
| `09_Cover_Brief_Template.md` | The brief you hand a designer -- or Claude -- before any cover work: audience, tone, references, the avoid list, specs | Chapter 11, Build 2. Write it before you look at an image. |

## How to use them

1. Copy this folder into your book's project folder.
2. Give `00_Production_Run_Sheet.md` to Claude and say: "Run my production."
3. Claude will ask the intake questions, then work through the run sheet, filling in each template as it goes.
4. When Claude hands you a task marked "Author," open the template and the website side by side. The fields are pre-filled. You click the buttons.

## The owner column

Every task is marked Claude or Author.

**Claude's lane:** Pre-fill data, compute numbers, draft documents, build files, run QA checks, give you exact instructions for each account.

**Your lane:** Account actions that require your logins — buying ISBNs, uploading to platforms, filing copyright, mailing deposit copies. Claude cannot do these and should never ask for your passwords.

That's the whole division of labor.
