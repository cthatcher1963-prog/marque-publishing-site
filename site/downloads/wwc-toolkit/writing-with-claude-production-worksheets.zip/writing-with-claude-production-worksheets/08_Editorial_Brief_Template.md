# Editorial Brief -- Template

*Companion to* Writing with Claude, *Chapters 10 and 11. Write this before you talk to a single editor. Give it to Claude with your Canon, voice profile, and rules file and say: "Draft my editorial brief from these." Then rewrite the cover note and the voice section in your own words -- those two are you talking, not the machine. If you end up doing the edit with Claude instead of a person, this brief becomes Claude's instructions.*

---

## Cover note (you write this)

Two or three paragraphs, in your voice. Who you are, what the book is, why you are self-publishing, what you want from the person reading this. Say plainly that you used AI in drafting and what has already been done about it. Editors find out anyway; telling them first is the credibility move.

## At a glance

| Field | Your book |
|---|---|
| Title / subtitle | |
| Author | |
| Genre | |
| Length | ~__,___ words, __ chapters, plus front/back matter |
| Audience | Who buys this, in one sentence |
| Format | e.g. trade paperback 6x9 and Kindle, self-published via KDP |
| Delivery to editor | Date |
| Target ship date | Date |

## About the author

One paragraph, from your facts file. Nothing in it the facts file cannot support.

## The voice (read this first)

The section that matters most. What distinguishes your voice from everyone else on your shelf. Then two lists, drawn from your voice profile:

**Tics that stay.** The things that look like mistakes and are not. Signature openers, deliberate em-dashes, one-sentence paragraphs, recurring metaphors, anchor phrases that reference a story. Name each one so it is not "fixed."

**Moves to push back on.** Where your prose drifts when it drifts -- consultant-speak, jargon that was never translated, fear-selling, overselling yourself. Ask for a query, not a rewrite.

## Scope of the edit

**What I am asking for:** e.g. a combined line edit and copyedit against Chicago.

**What I am not asking for:** e.g. developmental editing. Structure is locked.

**The disqualifying rule:** An edit is not a rewrite. A sample that rewrites my sentences instead of correcting them is an automatic no. Say it in exactly the words you will score against.

## Style conventions

| Item | Decision |
|---|---|
| Style guide | e.g. Chicago Manual of Style (note edition on the style sheet) |
| Spelling | e.g. U.S. English, Merriam-Webster |
| Serial comma | Yes / No |
| Numbers | Your rule |
| Em-dashes | Closed / spaced; note if heavy use is intentional |
| Quotations | Curly quotes; block-quote threshold |
| Citations | How light or heavy; what to verify |
| Acronyms | Defined on first use; query undefined ones |

## Timeline

Delivery date to editor, turnaround you need, ship date, and what is running in parallel (cover, production).

## Deliverables

- Edited manuscript in Word with Track Changes on
- Author query list -- explicit ("Did you mean X or Y?"), not generic ("clarify")
- Style sheet: names, terms, hyphenations, capitalizations, deliberate non-standard choices
- Optional one-page closing memo on anything structural for the next edition

## Compensation

Ask for their fee structure, or state your budget.

## How to respond

What you want back: relevant experience, a quote, calendar confirmation, and a one-paragraph reaction to the sample chapter. Ask for their instincts, not a free sample edit -- then, for the finalists, request the same short sample edit from each so you can score them against the disqualifying rule.

## Sample chapter

Attach one representative chapter, ~3,000 words, your most recently revised. Say what it is representative of.
