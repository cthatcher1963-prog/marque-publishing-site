# Copyright Page Template — [Title]

## Instructions

Fill the brackets. Output a clean, paste-ready page. Keep what applies, drop what doesn't. Every format's ISBN must appear — one line per format, even when using placeholders. A missing line is a missing line of height, and that changes the page count.

**Placeholder discipline:** Use correctly-sized placeholders (same digit count) for any identifier that hasn't arrived yet. Every line the final page will carry must be present now. After substituting real identifiers, re-run the build and confirm the page count is unchanged.

---

## The Page

```
[BOOK TITLE]
[Subtitle]

Copyright (c) [YEAR] by [AUTHOR or RIGHTS HOLDER]

All rights reserved. No part of this book may be reproduced, distributed, 
or transmitted in any form or by any means, including photocopying, 
recording, or other electronic or mechanical methods, without the prior 
written permission of the publisher, except in the case of brief 
quotations embodied in critical reviews and certain other noncommercial 
uses permitted by copyright law.

Published by [YOUR IMPRINT]
[City, State]
[website]

[CHOOSE ONE DISCLAIMER — delete the other:]

[FICTION:]
This is a work of fiction. Names, characters, places, and incidents are 
products of the author's imagination or used fictitiously. Any 
resemblance to actual persons, living or dead, events, or locales is 
entirely coincidental.

[FICTION WITH REAL PEOPLE — use instead of the above:]
This is a work of fiction. Certain real persons and historical events 
appear in these pages and are used fictitiously; all dialogue, motive, 
and action attributed to them is the product of the author's imagination. 
All other names, characters, places, and incidents are the product of the 
author's imagination, and any resemblance to actual persons, living or 
dead, events, or locales is entirely coincidental.

[NONFICTION:]
The information in this book is provided for general informational 
purposes and does not constitute [legal / financial / professional] 
advice. The author and publisher disclaim any liability arising from the 
use of the information herein.

Library of Congress Control Number: [LCCN or placeholder]

ISBN (paperback): [978-#-######-##-#]
ISBN (hardcover): [978-#-######-##-#]
ISBN (ebook):     [978-#-######-##-#]

[Edition line:] First Edition, [Year]
[Optional:] Cover design by [name]. Edited by [name].

Printed in the United States of America
```

---

## Notes

| Item | Rule |
|------|------|
| Copyright year | Year of first publication of that edition |
| ISBN lines | Only list formats that exist. Remove the rest. But if a format is planned, keep the placeholder line — adding it later changes page count. |
| LCCN line | Include only if a PCN was obtained before publication. If not obtained, omit the entire line. |
| Imprint name | Must be identical to what's registered in Bowker and entered at each retailer. |
| "Printed in" line | Print editions only. Omit from the ebook copyright page. |
| Disclaimer | Fiction → fiction disclaimer. Fiction with real people → modified disclaimer. Nonfiction → nonfiction disclaimer. The disclaimer never names specific real people — that belongs in a back-matter Author's Note. |

---

## Ebook Copyright Page

The ebook version correctly **omits**:
- The LCCN line (ebooks are ineligible for the PCN program)
- The "Printed in the United States of America" line

An ebook without these lines is correct as built. Do not add them.
