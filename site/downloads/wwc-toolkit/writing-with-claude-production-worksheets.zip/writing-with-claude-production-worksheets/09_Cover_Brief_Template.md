# Cover Brief -- Template

*Companion to* Writing with Claude, *Chapter 11, Build 2. Write this before you look at a single image, whether the designer is a person or an AI. Give it to Claude with your Canon and thesis and say: "Draft my cover brief from these." Then rewrite "What the book actually is" and "Tone" yourself -- if those two sections sound like anyone else's book, the cover will look like anyone else's cover. The avoid list is the disqualifier: a concept that uses anything on it ends the conversation.*

---

## Project at a glance

| Field | Your book |
|---|---|
| Title | (locked text for layout) |
| Subtitle | (locked text for layout) |
| Author | |
| Format | e.g. paperback + Kindle via KDP; hardcover via IngramSpark |
| Genre / category | Store category, in the store's words |
| Length | ~__,___ words / ~___ pages, __ x __ trim |
| Target ship date | |

## Audience

Who picks this up, and what else is on their nightstand. Name three books they already own. What makes them put a book down.

## What the book actually is

One paragraph, in your words. The promise, the voice, the reason it exists. Then the two or three signature ideas a concept can anchor on -- a metaphor, a question, a phrase from the book -- and how literally each one may be shown.

## Tone

Three or four adjectives and a comparison a designer can picture ("editorial book section, not vendor booth"). What the cover should make the reader feel before they read a word.

## The two jobs

Every cover has to do two things that pull against each other. Say how you want them balanced:

1. **Credibility at print scale** -- what it must feel like in the hand.
2. **Presence at thumbnail scale** -- most discovery happens at about 200 pixels tall. Bold color, dominant title typography, one conceptual element.

## Reference covers

Four to eight real covers, split into what to learn from each: typography discipline, thumbnail presence, conceptual confidence. Say what ties them together.

## Avoid list -- the disqualifier

The cliches of your shelf. Be specific (for a cybersecurity book: glowing padlocks, hooded hackers, falling green code, world maps with red dots). Any concept that uses one is a no, and you say so up front.

## The authenticity rule

If anything on the cover depicts something real -- an object, a place, a person -- it is verified real or it is not on the cover. (The Treasure Hunter's Legacy shipped with photographs of an actual eight-reale coin, not AI-generated pirate silver.)

## Deliverables

1. Ebook front cover -- e.g. 1600 x 2560 px, sRGB, JPG
2. Paperback full wrap -- back + spine + front as one print-ready PDF to platform spec
3. Source files -- layered working file, fonts packaged or outlined, so revisions are possible

## Technical specifications

Trim size. Interior paper and page count (provisional until frozen). Spine width from the platform's cover calculator. Full-wrap dimensions including bleed. Resolution (300 DPI). Color space (CMYK wrap, sRGB ebook). Safety zones. File formats. What the author supplies for the back cover: blurb (~150 words), bio (~50 words), headshot, barcode box.

Fill this section from `05_Cover_Wrap_Spec.md` once the page count is frozen. Until then, mark every number provisional.

## Timeline and rounds

Concept round, revision rounds, final files. How many rounds are included. Your exit criteria for any "modify the existing cover" request -- set the time limit before it starts.

## How to respond

Portfolio links in this genre, a quote, and one paragraph on how they would approach the brief. Instincts, not a free concept.
