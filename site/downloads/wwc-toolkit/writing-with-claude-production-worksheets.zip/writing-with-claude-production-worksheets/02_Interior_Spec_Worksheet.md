# Interior Spec Worksheet — [Title]

**Genre:** [ ] Fiction  [ ] Nonfiction
**Date locked:** [YYYY-MM-DD]

---

## Instructions

This is the one-page spec that controls your entire interior. Lock every decision before typesetting begins. Give this file to Claude and tell it to typeset to this spec exactly.

Ask Claude: *"Research standard interior conventions for [my genre]. Produce a one-page interior spec covering trim size, typeface, margins, running heads, page numbers, chapter openings, and matter order. My north star authors are [names]."*

Then fill this sheet with the answers you approve.

**Fiction and nonfiction are different systems.** Fiction: first-line indent, justified, no paragraph spacing. Nonfiction: block paragraphs, left-aligned, 6pt paragraph spacing. Applying the wrong system makes a novel look like a business report, or a business book look like a novel.

---

## The Eight Decisions

| # | Decision | Your spec |
|---|----------|-----------|
| 1 | **Trim size** | _______ × _______ in. *(Common: 6×9 fiction, 5.5×8.5 business, 5×8 mass market)* |
| 2 | **Typeface** | _______ at _______ pt *(Compare x-height, not nominal size. Classic serifs: Palatino, Garamond, Minion, Caslon)* |
| 3 | **Leading** | _______ pt *(Target: 130-135% of type size for fiction. Faces with small x-heights need more.)* |
| 4 | **Margins** | Top: _____ Bottom: _____ Inside (gutter): _____ Outside: _____ *(Mirror margins for recto/verso)* |
| 5 | **Running heads** | Verso (left page): _____________ Recto (right page): _____________ *(Common: author name verso, chapter title recto)* |
| 6 | **Page numbers (folios)** | Position: _____________ *(Common: bottom center or bottom outside corners)* |
| 7 | **Chapter openings** | [ ] Right-hand page (recto) — fiction standard [ ] Next page *(Recto starts mean blank versos between chapters. This affects page count.)* |
| 8 | **Matter order** | See table below |

---

## Matter Order

Fill in what applies. Drop what doesn't. This order is conventional.

### Front Matter
| Component | Include? | Notes |
|-----------|----------|-------|
| Half title | [ ] | Title only, no subtitle or author |
| Title page | [ ] | Title, subtitle, author, imprint |
| Copyright page | [ ] | Use `03_Copyright_Page_Template.md` |
| Dedication | [ ] | |
| Epigraph | [ ] | |
| Table of contents | [ ] | |
| Foreword | [ ] | By someone other than the author — triggers Standard Application for copyright |
| Preface / Introduction | [ ] | |

### Back Matter
| Component | Include? | Notes |
|-----------|----------|-------|
| Author's note | [ ] | |
| Acknowledgments | [ ] | Real names, spelled right |
| About the author | [ ] | From the facts file — nothing unverified |
| Also by | [ ] | |
| Appendix | [ ] | |

---

## Paragraph Style

| Setting | Fiction | Nonfiction |
|---------|---------|------------|
| First-line indent | Yes (0.25-0.35 in) | No |
| Paragraph spacing | No spacing | 6pt after |
| Alignment | Justified | Left-aligned |
| First paragraph after heading | No indent | N/A |

---

## Geometry Check (run against the built PDF)

| Metric | Target | Actual |
|--------|--------|--------|
| Characters per line | 60-68 | _______ |
| Words per page (body text) | 250-300 at 6×9 | _______ |
| Leading as % of type size | 130-135% (fiction) | _______% |

---

## Traps to Check

- [ ] Sentence spacing set AFTER `\begin{document}` (polyglossia/babel override it in the preamble)
- [ ] Widows and orphans prevented (`\widowpenalty=10000`, `\clubpenalty=10000`, `\raggedbottom`)
- [ ] No scene-break ornament at page foot with no text beneath it
- [ ] No editorial markers in the PDF (`--- END OF CHAPTER ---`, `TK`, `TODO`, `[insert`)
- [ ] Non-ASCII renders correctly (accents, tildes, inverted punctuation)
- [ ] Page count and trim dimensions read from the PDF match what you specified
- [ ] Export from the same engine that set the type (not via LibreOffice — it repaginates)
