# Platform Upload Checklist — [Title]

**Date:** [YYYY-MM-DD]

---

## Instructions

One section per platform. Claude pre-fills the field values from your metadata worksheet and ISBN log. You open the platform and the checklist side by side, work the fields in, and check each one complete. That's the sitting pattern — data sheet on the left, platform on the right.

---

## KDP (Amazon)

**URL:** kdp.amazon.com/bookshelf

### Ebook

| Field | Value | Done |
|-------|-------|------|
| Title | | [ ] |
| Subtitle | | [ ] |
| Series / number | | [ ] |
| Author | | [ ] |
| Contributors | | [ ] |
| Description | *(from metadata worksheet)* | [ ] |
| Keywords (7) | *(from metadata worksheet)* | [ ] |
| Categories | *(from metadata worksheet)* | [ ] |
| ISBN | *(ebook ISBN from log)* | [ ] |
| Publisher | *(imprint name — must match Bowker exactly)* | [ ] |
| Publication date | | [ ] |
| DRM | [ ] Yes [ ] No | [ ] |
| KDP Select (exclusivity) | [ ] Yes [ ] No *(enrolling = exclusive to Amazon)* | [ ] |
| Price | $ _______ | [ ] |
| Royalty tier | [ ] 35% [ ] 70% *(verify current ceiling on KDP pricing page)* | [ ] |
| Territory | [ ] All territories [ ] Specific | [ ] |
| Upload manuscript file | *(EPUB or .docx)* | [ ] |
| Upload cover | *(front cover only — KDP adds barcode)* | [ ] |
| Preview and approve | | [ ] |

### Paperback

| Field | Value | Done |
|-------|-------|------|
| ISBN | *(paperback ISBN from log — NOT the ebook ISBN)* | [ ] |
| Publisher / imprint | | [ ] |
| Publication date | | [ ] |
| Trim size | _______ × _______ in | [ ] |
| Interior | [ ] Black & white [ ] Color | [ ] |
| Paper | [ ] Cream [ ] White | [ ] |
| Bleed | [ ] Yes [ ] No | [ ] |
| Price | $ _______ | [ ] |
| Upload interior PDF | *(print-ready, from Build B)* | [ ] |
| Upload cover wrap | *(full wrap PDF — KDP adds its own barcode, remove yours)* | [ ] |
| Preview and approve | | [ ] |

### Hardcover

| Field | Value | Done |
|-------|-------|------|
| ISBN | *(hardcover ISBN from log — NOT the paperback ISBN)* | [ ] |
| All fields same as paperback | *(with hardcover-specific stock values)* | [ ] |
| Cover wrap | *(built from Amazon's own template ZIP — different spine math)* | [ ] |
| Upload and approve | | [ ] |

---

## IngramSpark

**URL:** myaccount.ingramspark.com

| Field | Value | Done |
|-------|-------|------|
| Title | | [ ] |
| ISBN | *(this format's ISBN — verify against log)* | [ ] |
| Publisher | *(imprint — must match Bowker exactly or the upload errors)* | [ ] |
| Trim size | | [ ] |
| Interior color | | [ ] |
| Paper stock | | [ ] |
| Binding | [ ] Perfect bound [ ] Case laminate [ ] Other | [ ] |
| Price | $ _______ | [ ] |
| Distribution | *(IngramSpark's distribution network — global reach)* | [ ] |
| Upload interior PDF | | [ ] |
| Upload cover PDF | *(you supply the barcode — text must be outlined)* | [ ] |
| Review and submit | | [ ] |

---

## B&N Press

**URL:** press.barnesandnoble.com

| Field | Value | Done |
|-------|-------|------|
| Title | | [ ] |
| ISBN | *(this format's ISBN)* | [ ] |
| Publisher | | [ ] |
| All standard fields | *(from metadata worksheet)* | [ ] |
| Upload files | | [ ] |
| Review and approve | | [ ] |

---

## Draft2Digital

**URL:** draft2digital.com

| Field | Value | Done |
|-------|-------|------|
| Title | | [ ] |
| ISBN | *(this format's ISBN)* | [ ] |
| All standard fields | *(from metadata worksheet)* | [ ] |
| Upload manuscript | | [ ] |
| Distribution channels | *(select retailers)* | [ ] |
| Review and approve | | [ ] |

---

## Post-Upload Checks (all platforms)

- [ ] Listing is live or scheduled for publication date
- [ ] Title, author, and imprint display correctly
- [ ] Price and royalty tier are what you intended
- [ ] Categories and keywords are applied
- [ ] Cover displays correctly in the listing
- [ ] ASIN / listing ID recorded in session log
- [ ] Author page claimed and populated (bio from facts file)
