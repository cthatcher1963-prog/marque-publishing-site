# Deposit and Registration Submission Sheet — [Title]

**Publication date:** [YYYY-MM-DD]
**Three-month deadline:** [YYYY-MM-DD]
**Date filed:** [YYYY-MM-DD]

---

## Instructions

Claude pre-fills every field value below. You file and pay at copyright.gov, then print the shipping slip and mail the copies. Three separate obligations, two shipments, three copies total.

**Know your deadline before you publish.** The three-month clock starts on your publication date and governs statutory-damages eligibility. Miss it and the effective date of registration resets — which is the date that matters for enforcement.

---

## The Three Obligations

*These are constantly conflated. They are separate.*

| # | Obligation | Copies | Deadline | Where to send |
|---|-----------|--------|----------|---------------|
| 1 | **PCN program copy** (LCCN commitment) | 1 | Immediately upon publication | Library of Congress, Cataloging in Publication Program, Washington DC 20540-4283 |
| 2 | **Mandatory deposit §407** | 2 of the best edition | 3 months from publication | Copyright Office |
| 3 | **Copyright registration §408** | 1 (send 2) | 3 months, to preserve statutory damages | Copyright Office, Washington DC 20559-6222 |

**Filing a registration with two copies of the best edition satisfies §407 at the same time.** That means:

- **Shipment 1 → Copyright Office:** 2 copies + shipping slip from eCO = registration + mandatory deposit, both handled.
- **Shipment 2 → Library of Congress:** 1 copy = PCN obligation fulfilled.

---

## Copyright Registration — Pre-Filled Fields

*Claude fills these. You transcribe them into copyright.gov when you file.*

| Field | Value |
|-------|-------|
| **Application type** | [ ] Standard ($65) [ ] Single ($45) — see rules below |
| **Type of work** | Literary Work |
| **Title** | |
| **Previous or alternative titles** | |
| **Year of creation** | |
| **Author** | |
| **Author nationality / domicile** | |
| **Work made for hire?** | [ ] Yes [ ] No |
| **Claimant name** | |
| **Claimant address** | |
| **Publication status** | Published |
| **Date of first publication** | |
| **Nation of first publication** | United States |
| **Pre-existing material** | [ ] None [ ] Describe: _________________ |
| **Rights and permissions contact** | |

---

## Application Type — This Matters

**The Marque default is the Standard Application.**

| Condition | Required application |
|-----------|---------------------|
| Sole author, no other contributors | Single Application is permitted |
| **Any** contributor (foreword, afterword, introduction by another person) | **Standard Application required** |
| Work made for hire | Standard Application required |

**⚠ A Single Application is illegal for a book with a foreword by another person.** The Copyright Office publishes this exact fact pattern as a disqualifying example. A wrong filing is refused, the fee is not refunded, the deposit copy is consumed, and the effective date of registration resets.

**Fees change.** Always verify the current fee at copyright.gov/about/fees.html before filing. Do not use a number from memory.

---

## Mailing Checklist

### Shipment 1 — Copyright Office (registration + deposit)

- [ ] Registration filed at copyright.gov
- [ ] Fee paid
- [ ] Shipping slip printed from eCO *(generated only AFTER payment — must physically go in the box)*
- [ ] 2 copies of the **best edition** packed *(best edition = hardcover when both bindings exist, not one of each, never the ebook)*
- [ ] Shipping slip in the box
- [ ] Shipped to: Copyright Office, Washington DC 20559-6222
- [ ] Tracking number recorded: _______________

### Shipment 2 — Library of Congress (PCN copy)

- [ ] 1 copy of the published book packed
- [ ] Shipped to: Library of Congress, Cataloging in Publication Program, Washington DC 20540-4283
- [ ] Tracking number recorded: _______________

---

## Post-Filing

- [ ] Registration confirmation received (case number): _______________
- [ ] Effective date of registration: _______________
- [ ] ISBN log updated
- [ ] Session log updated with filing dates, tracking numbers, and deadlines
- [ ] All three obligations fulfilled: [ ] Registration [ ] §407 deposit [ ] PCN copy

---

## Notes

This is procedural information assembled from publicly available Copyright Office circulars and regulations, not legal advice. Consult an attorney for questions about your specific situation.
