# ISBN Log — Instructions

This log is the source of truth for every ISBN your imprint owns. One log across all titles, maintained for the life of the imprint. Give it to Claude at the start of every production run.

## Rules

1. **One ISBN per format, per edition.** Paperback, hardcover, ebook, and audiobook each get their own. A revised edition needs new ISBNs; a straight reprint does not.

2. **PENDING → SPENT.** When you purchase ISBNs from Bowker, log them immediately as PENDING with the title and format they're reserved for. When you assign them in Bowker (irreversible), update the status to SPENT and fill the `date_assigned` field.

3. **Never use a free platform ISBN.** A free ISBN from KDP, IngramSpark, or B&N Press makes the platform your publisher of record, hides your imprint, and locks the book to that platform. The entire point of owning your imprint is to own the identifier.

4. **Never guess which numbers are available.** Read the log. If a number isn't in the log, it hasn't been reserved. If it shows SPENT, it's gone.

## Columns

| Column | What goes here |
|--------|---------------|
| isbn | The full 13-digit ISBN (978-...) |
| title | Book title |
| subtitle | Book subtitle |
| format | paperback, hardcover, ebook, or audiobook |
| edition | First, Second, etc. |
| date_reserved | Date you purchased/reserved the ISBN from Bowker |
| date_assigned | Date you assigned it in Bowker (leave blank until assigned) |
| imprint | Your imprint name exactly as registered in Bowker |
| status | PENDING (reserved, not yet assigned) or SPENT (assigned in Bowker — irreversible) |
| channel | Where this format will be sold (KDP, IngramSpark, B&N Press, etc.) |
| notes | Anything else — backfill notes, corrections, etc. |

## Where to buy ISBNs

Bowker (myidentifiers.com) is the only authorized ISBN agency in the United States. Buy in blocks — a block of 10 is significantly cheaper per unit than singles. You will use them.
