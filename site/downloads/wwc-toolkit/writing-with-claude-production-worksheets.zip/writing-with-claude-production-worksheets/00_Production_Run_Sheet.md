# Production Run Sheet — [Title]

**Date opened:** [YYYY-MM-DD]
**Formats in this run:** [ ] Paperback  [ ] Hardcover  [ ] Ebook  [ ] Audiobook
**Planned publication date:** [YYYY-MM-DD]
**Genre:** [ ] Fiction  [ ] Nonfiction

---

## How to use this sheet

Give this file to Claude at the start of your production run. It becomes your checklist, your handoff sheet, and your audit trail. Every line has an owner — Claude or you. Claude pre-fills the data, drafts the documents, and computes the numbers. You do the account actions that require your logins.

Mark each task complete as you go. If a task has a warning icon (⚠), it is irreversible — read the note before you act.

---

## Phase 1 — Identity and Legal

*Platform-independent. Do this once regardless of how many formats or channels you're publishing to.*

| # | Task | Owner | Status | Notes |
|---|------|-------|--------|-------|
| 1.1 | Run intake — collect title, subtitle, author, formats, trim, price, channels, imprint, fiction/nonfiction | Claude | [ ] | Use the intake questions below |
| 1.2 | Reserve ISBNs from Bowker (myidentifiers.com) — one per format | Author | [ ] | ⚠ Do NOT use a free platform ISBN. It makes the platform your publisher of record and limits distribution. |
| 1.3 | Assign ISBNs to formats in Bowker | Author | [ ] | ⚠ Assignment is irreversible. Confirm format-to-number mapping before clicking. |
| 1.4 | Log ISBNs — update ISBN log, mark PENDING → SPENT | Claude | [ ] | Use `01_ISBN_Log.csv` |
| 1.5 | Generate barcodes | Claude | [ ] | Bookland EAN, `90000` price code unless price is final. KDP supplies its own; IngramSpark uses yours. |
| 1.6 | Draft copyright page | Claude | [ ] | Use `03_Copyright_Page_Template.md`. One placeholder line per format's ISBN + one LCCN line. |
| 1.7 | Apply for LCCN/PCN (pcn.loc.gov) — print editions only | Author | [ ] | Not on the critical path. Do not hold the cover behind it. Receiving an LCCN commits you to sending one copy to LOC upon publication — that is a Phase 3 obligation. |
| 1.8 | Draft BISAC codes and metadata worksheet | Claude | [ ] | Use `04_Metadata_Worksheet.md`. Max 3 BISAC codes. Primary chosen for positioning, not description. |
| 1.9 | Pre-fill copyright registration fields (do NOT file yet) | Claude | [ ] | Filing happens in Phase 3 after the book physically exists. This step assembles the values. |

---

## Phase 2 — Physical Build

*Per format, per platform. Phases 1 and 2 run in parallel. The only hard ordering: variable-length content → Build B → page count → spine → cover wrap.*

| # | Task | Owner | Status | Notes |
|---|------|-------|--------|-------|
| 2.1 | Confirm all variable-length matter is final (dedication, epigraph, author's note, acknowledgments, about the author) | Author | [ ] | This is the real gate. Identifiers are fixed-width and don't affect page count. |
| 2.2 | Build B — production interior | Claude | [ ] | Use `02_Interior_Spec_Worksheet.md` for the spec. Interior must be typeset from the spec, not guessed. |
| 2.3 | Run interior QA | Claude | [ ] | 11-point checklist: ornament count, no foot ornaments, no editorial markers, recto starts, blank verso clean, running heads, non-ASCII, spot-render, geometry, copyright page lines, page count matches. |
| 2.4 | Freeze page count (from Build B PDF, not from the source doc) | Claude | [ ] | Write it here: _______ pages. Read from the PDF itself — a source-doc count is unreliable. |
| 2.5 | Compute spine width | Claude | [ ] | Cream stock: pages × 0.0025 in. White stock: pages × 0.002252 in. Confirm per platform against their calculator. Write it here: _______ in. |
| 2.6 | Substitute real ISBNs and LCCN into copyright page | Claude | [ ] | Re-run build. Confirm page count unchanged. If it moved, the placeholder was mis-sized — recompute spine. |
| 2.7 | Build cover wrap — paperback | Claude | [ ] | From `05_Cover_Wrap_Spec.md`. Sized to platform template. Author approves before upload. |
| 2.8 | Build cover wrap — hardcover | Claude | [ ] | Different stock values. Use the platform's own template ZIP if provided (Amazon provides one). |
| 2.9 | Build EPUB | Claude | [ ] | Reflowable — built from normalized source, not from the print PDF. Copyright page omits LCCN and "Printed in" line. |
| 2.10 | Run epubcheck on EPUB | Claude | [ ] | Must pass VALID. |
| 2.11 | Upload interior — ebook | Author | [ ] | Platform validation will catch format errors. |
| 2.12 | Set up ebook preorder | Author | [ ] | Get it live while finishing print files. Set pub date, price, categories. Check royalty tier ceiling — verify the current number on the platform's live pricing page, not from memory. |
| 2.13 | Upload interior — paperback | Author | [ ] | Print-ready PDF. |
| 2.14 | Upload interior — hardcover | Author | [ ] | Print-ready PDF. |
| 2.15 | Upload cover wraps | Author | [ ] | ⚠ Proofread the ISBN on each wrap per format. A hardcover wrap carrying the paperback ISBN passes every dimension check. Compare against the ISBN log. Remove embedded barcode if the platform adds its own. |
| 2.16 | Set pricing per format per platform | Author | [ ] | ⚠ Ebook pricing cliff: 70% royalty tier has a ceiling that changes — verify the current number on the platform's live pricing page, not from memory or training data. Above the ceiling, 35%. Don't let a print price default into the ebook field. |
| 2.17 | Order proof copies — every format | Author | [ ] | Read them. Fix what you find. Re-proof if fixes were significant. |
| 2.18 | Build author page on each platform | Author | [ ] | Bio from the facts file. Checked once against the facts file, then copied. |

---

## Phase 3 — Post-Publication Legal

*Cannot start before the book physically exists. Has a hard three-month clock.*

| # | Task | Owner | Status | Notes |
|---|------|-------|--------|-------|
| 3.1 | Calculate deposit deadlines from publication date | Claude | [ ] | Pub date: ________. Deadline: ________ (3 months). Write the dates here. Know them before you publish. |
| 3.2 | File copyright registration at copyright.gov | Author | [ ] | Claude pre-fills the form values in `07_Deposit_and_Registration.md`. You file and pay. ⚠ Standard Application is the Marque default. A Single Application is illegal if anyone other than the author contributed (foreword, introduction). Wrong filing = fee lost, deposit consumed, effective date reset. |
| 3.3 | Print the shipping slip from eCO | Author | [ ] | Generated only AFTER payment. Must physically go in the box or the deposit can't be matched to the application. |
| 3.4 | Mail deposit copies to Copyright Office | Author | [ ] | Send 2 copies of the best edition (hardcover if both bindings exist). Filing registration with 2 copies satisfies §407 mandatory deposit at the same time. |
| 3.5 | Mail 1 copy to Library of Congress (PCN obligation) | Author | [ ] | Separate from the copyright deposit. This is the LCCN commitment — one copy, immediately upon publication. Address: LOC Cataloging in Publication Program, ZIP 20540-4283. |
| 3.6 | Confirm LCCN appears on copyright page of printed book | Author | [ ] | Visual check on the proof or final copy. |
| 3.7 | Update ISBN log — all ISBNs SPENT with final status | Claude | [ ] | |
| 3.8 | Update session log with production record | Claude | [ ] | What was produced, ISBNs spent, page count, spine width, pending items. |

---

## Intake Questions

Fill these before starting. Claude will ask for anything missing.

- **Title (exact, final):**
- **Subtitle:**
- **Author / contributors:**
- **Is there a foreword, afterword, or introduction by someone other than the author?** [ ] Yes [ ] No *(This determines which copyright application is legal to use. Ask now, not in Phase 3.)*
- **Formats in this run:** [ ] Paperback [ ] Hardcover [ ] Ebook [ ] Audiobook
- **New title or new edition?** *(A revised edition needs new ISBNs; a straight reprint does not.)*
- **Trim size:**
- **List price(s):** PB: $_____ HC: $_____ EB: $_____ Audio: $_____
- **Planned publication date:**
- **Fiction or nonfiction?** *(Routes the interior spec — they are different systems.)*
- **Channels:** [ ] KDP [ ] IngramSpark [ ] B&N Press [ ] Draft2Digital [ ] Direct
- **Imprint name (exact):** Marque Publishing, LLC *(or your imprint — must match Bowker registration exactly)*

**Do NOT collect page count here.** It is an output of Build B. Asking for it invites a guess, and a guessed page count produces a wrong spine and a rejected cover.
