# Metadata Worksheet — [Title]

**Date completed:** [YYYY-MM-DD]

---

## Instructions

One sheet per title. Fill it once. Reuse the values at every retailer so the record is consistent across platforms. Give this file to Claude before any upload sitting — it pre-fills the platform fields from these values.

---

## Identity

| Field | Value |
|-------|-------|
| **Title** | |
| **Subtitle** | *(Nonfiction: load buyer-search language here — this is a discovery surface)* |
| **Series / number** | *(if any)* |
| **Author** | |
| **Contributors** | *(foreword by, editor, illustrator — list all)* |
| **Imprint** | *(exact — must match Bowker registration)* |
| **Publication date** | |

---

## Formats and ISBNs

*Copy from the ISBN log. One line per format in this run.*

| Format | ISBN | Status |
|--------|------|--------|
| Paperback | | |
| Hardcover | | |
| Ebook | | |
| Audiobook | | |

---

## BISAC Codes

*Max 3. Confirm each code is active in the current BISAC edition. The primary is chosen for positioning — where the buyer browses, not just what the book is about.*

| Priority | Code | Category name |
|----------|------|---------------|
| **Primary** | | |
| Secondary | | |
| Tertiary | | |

---

## Description

**Hook (first 2 lines — shows above the fold on every platform):**

> [Write the hook here. These two lines are the most important copy in your listing.]

**Full description:**

> [Write the full description here. 150-300 words. Lead with what the reader gets, not what the book contains.]

---

## Keywords

*7 buyer-intent phrases. Do not repeat words from your title, author name, or BISAC categories — the platforms already index those. Think about what your reader types into the search bar.*

| # | Keyword phrase |
|---|----------------|
| 1 | |
| 2 | |
| 3 | |
| 4 | |
| 5 | |
| 6 | |
| 7 | |

---

## Category Targets

*Per retailer. Target niche subcategories where ranking is achievable, not broad top-level categories.*

| Platform | Category 1 | Category 2 |
|----------|-----------|-----------|
| Amazon | | |
| B&N | | |
| Other | | |

---

## Pricing

| Format | List price | Royalty tier | Net per sale |
|--------|-----------|-------------|-------------|
| Paperback | $ | | $ |
| Hardcover | $ | | $ |
| Ebook | $ | | $ |
| Audiobook | $ | | $ |

**Ebook pricing cliff:** The 70% royalty tier on Amazon is only available between $2.99 and a ceiling that changes — verify the current number on KDP's live pricing page before setting your price. Above the ceiling, the only option is 35%. Do not let a print price default into the ebook field.

---

## Audience

*(Who is this book for? One sentence. e.g., "Executives and board members responsible for cybersecurity risk" / "Adult readers of action-adventure fiction" / "Recreational poker players moving from casual to competitive")*

---

## Status Checklist

- [ ] ISBNs assigned and logged
- [ ] Barcode handled (platform-supplied or self-generated)
- [ ] Copyright page finalized with real identifiers
- [ ] LCCN/PCN obtained (print editions, before publication)
- [ ] Copyright registration filed (within 3 months of publication)
- [ ] Uploaded to: [ ] KDP [ ] IngramSpark [ ] B&N Press [ ] Draft2Digital
- [ ] Author page built on each platform
- [ ] Session log updated
